# Resumen del vídeo 5: Navegación por el mapa:

- [Ir al índice](index.md)
- [ir a resumen anterior](video4.md)
- [ir a resumen siguiente](video6.md)

## comandos de altitud en Eurofly3

para ver la altitud a la que estás en el terreno con respecto al nivel del mar tienes que pulsar ; (punto y coma); luego para ver el punto más cercano es con control punto y coma (lo que en la vida real nos haría un control shift coma); y para poder ver los puntos altos cercanos a tu ubicación desde una altura específica, hay que ingresar la altitud desde la que quieres mirar en un cuadro de texto que se abre con control shift punto y coma (que en la práctica nos daría el control punto y coma.

- [ir a resumen anterior](video4.md)
- [ir a resumen siguiente](video6.md)
- [Ir al índice](index.md)