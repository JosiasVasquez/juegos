# Resumen del Video 11: Plan de vuelo.

- [Ir al índice](index.md)
- [ir a resumen anterior](video10.md)
- [ir a resumen siguiente](video12.md)

Cómo crear un plan de vuelo y las diferentes modalidades de plan que existen. 

Son 3: una por medio de puntos que asigna la torre aleatoriamente, el otro directo (es decir en línea recta) y uno mediante los puntos de navegación que nosotros mismos elijamos en nuestro propio plan.

Algunas cosas importantes como que no te van a asignar ni una puerta ni una pista de despegue si no has mandado tu plan de vuelo para que e lo aprueben.

Además de eso  mostró algunas características del plan de vuelo, las cuales se pueden ver dando tab en la pantalla de navegación. Ahí saldrá toda la información como punto de partida, de llegada, aeropuerto alternativo, las ganancias y pérdidas del vuelo tanto en dinero como en puntos de rango, también la cantidad de combustible que es necesaria para realizar el vuelo.

También les digo que en esta versión de Eurofly a olvidarnos de volar solo en línea recta. Dijo que en la gran mayoría de los casos te van a asignar un corredor de vuelo y habrá que ir tocando esos vórtices aéreos para seguir la ruta que nos asignen hasta llegar al aeropuerto de destino.

Entre otras cosas también mostró el radar de tráfico actual, en el que además de ver quién está en el aire veremos los que están en un aeropuerto y en cual. También se podrá ver en línea y se actualizará siempre en tiempo real, es decir que ya no se depende de ingresar códigos de transpondedor a cada instante para que se actualice la información.

- [ir a resumen anterior](video10.md)
- [ir a resumen siguiente](video12.md)
- [Ir al índice](index.md)