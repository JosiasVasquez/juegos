# Resumenes de vídeo tutoriales de EuroFly3

- [vídeo 5: Navegación por el mapa.](video5.md)
- [video 6: Tipos de vuelos y aviones.](video6.md)
- [Video 7: Propiedades del avión.](video7.md)
- [Video 8: Manejando el avión.](video8.md)
- [Video 9: Navegación y puntos de dirección.](video9.md)
- [Video 10: Utilizar las radios y las frecuencias.](video10.md)
- [Video 11: Plan de vuelo.](video11.md)
- [Video 12: Aeropuertos y cómo navegarlos.](video12.md)
- [Video 13: Mapas de decenso y el ILS.](video13.md)
- [Video 14: El Comunicador.](video14.md)